const futebol = prompt(
  "De Qual time da série A do Brasileirão você quer saber?"
).toLowerCase();
if (futebol == "flamengo") {
  console.log(
    "O Flamengo atualmente está em 4° Lugar no Brasileirão, e disputando Copa do Brasil e Brasileirão"
  );
} else if (futebol == "vasco") {
  console.log(
    "O Vasco atualmente está em 9° Lugar no Brasileirão, e disputando Brasileirão e Copa do Brasil"
  );
} else if (futebol == "criciuma") {
  console.log(
    "O Criciuma atualmente está em 12° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
} else if (futebol == "botafogo") {
  console.log(
    "O Botafogo atualmente está em 1° Lugar no Brasileirão, e disputando Brasileirão e Libertadores"
  );
} else if (futebol == "palmeiras") {
  console.log(
    "O Palmeiras atualmente está em 2° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
} else if (futebol == "atletico-go") {
  console.log(
    "O Atlético-Go atualmente está em 20° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "são paulo") {
  console.log(
    "O São Paulo atualmente está em 5° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "bragantino") {
  console.log(
    "O Bragantino atualmente está em 13° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "corinthians") {
  console.log(
    "O Corinthians atualmente está em 18° Lugar no Brasileirão, e disputando Brasileirão e Copa do Brasil"
  );
}else if (futebol == "cuiabá") {
  console.log(
    "O Cuiabá atualmente está em 19° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "atletico-mg") {
  console.log(
    "O Atletico-MG atualmente está em 10° Lugar no Brasileirão, e disputando Brasileirão, Copa do Brasil e Libertadores"
  );
}else if (futebol == "vitoria") {
  console.log(
    "O Vitória atualmente está em 17° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "fluminense") {
  console.log(
    "O Fluminense atualmente está em 16° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "athletico-pr") {
  console.log(
    "O Athletico-PR atualmente está em 15° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == 'juventude') {
  console.log(
    "O Juventude atualmente está em 14° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "grêmio") {
  console.log(
    "O Grêmio atualmente está em 11° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "cruzeiro") {
  console.log(
    "O Cruzeiro atualmente está em 8° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "bahia") {
  console.log(
    "O Bahia atualmente está em 7° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "internacional") {
  console.log(
    "O Internacional atualmente está em 6° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else if (futebol == "fortaleza") {
  console.log(
    "O Fortaleza atualmente está em 3° Lugar no Brasileirão, e disputando Somente Brasileirão"
  );
}else {
  console.log("Este time não está no brasieirão serie A.");
}
